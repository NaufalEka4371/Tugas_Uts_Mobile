package com.naufal.umkmchatapp

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etNama = findViewById<EditText>(R.id.etNama)
        val etPass = findViewById<EditText>(R.id.etPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val btnBack = findViewById<Button>(R.id.btnBackToLogin)

        val sharedPref = getSharedPreferences("UserData", MODE_PRIVATE)

        // ✅ Perbaikan: Hanya satu setOnClickListener
        btnRegister.setOnClickListener {
            val nama = etNama.text.toString()
            val pass = etPass.text.toString()

            val editor = sharedPref.edit()
            editor.putString("username", nama)
            editor.putString("password", pass)
            editor.apply()

            Toast.makeText(this, "Register berhasil", Toast.LENGTH_SHORT).show()
            Log.d("RegisterLog", "Nama: $nama")

            finish() // Kembali ke login
        }

        btnBack.setOnClickListener {
            finish() // kembali ke LoginActivity
        }
    }
}

