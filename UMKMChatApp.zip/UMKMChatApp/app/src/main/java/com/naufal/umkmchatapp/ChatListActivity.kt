package com.naufal.umkmchatapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.ArrayAdapter
import android.widget.ListView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.graphics.Color



class ChatListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)

        val listView = findViewById<ListView>(R.id.listView)
        val data = arrayOf("Pelanggan A", "Pelanggan B", "Pelanggan C")

        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            data
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent) as TextView
                view.setTextColor(Color.BLACK) // Ganti warna teks jadi hitam
                return view
            }
        }
        listView.adapter = adapter
    }
}