package com.naufal.umkmchatapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnGoToRegister = findViewById<Button>(R.id.btnGoToRegister)

        val sharedPref = getSharedPreferences("UserData", MODE_PRIVATE)
        val savedUser = sharedPref.getString("username", null)
        val savedPass = sharedPref.getString("password", null)

        btnLogin.setOnClickListener {
            val inputUser = etUsername.text.toString()
            val inputPass = etPassword.text.toString()

            if ((inputUser == savedUser && inputPass == savedPass) ||
                (inputUser == "admin" && inputPass == "1234")) {
                startActivity(Intent(this, ChatListActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Login gagal!", Toast.LENGTH_SHORT).show()
            }
        }

        btnGoToRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}

